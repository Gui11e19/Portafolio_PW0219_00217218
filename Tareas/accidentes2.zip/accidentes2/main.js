let evento_field = document.querySelector("#accidente_field");
let dia_dropdown = document.querySelector("#dia_field");
let accidente_switch = document.querySelector("#accidente_switch");
let submit_btn = document.querySelector("#submit_btn");

let table_body = document.querySelector("#table_body");
let evento_regex = new RegExp('[a-z]');

let addEvento = (evento, dia, accidente) =>{
    let new_row = document.createElement("tr");
    let datetime = new Date();

    new_row.className="table_active"
    new_row.innerHTML = `<th scope='row'>${evento}</th>
    <td>${dia}</td>
    <td>${datetime.toLocaleString}</td>
    <td>${accidente}</td>
    `;

    table_body.appendChild(new_row);

    
}

let parseAccidenteSwitch = (value)=>{
    if(value){
        return "Tuvo Accidente"
    }
    return "No tuvo accidente"
}

submit_btn.addEventListener("click", ()=>{
    let evento = evento_field.value;
    let dia = dia_dropdown.options[dia_dropdown.selectedIndex].text;
    let late = parseAccidenteSwitch(accidente_switch.checked);

    if(evento_regex.test(evento)){
        addEvento(evento,dia,accidente);
    } else {
        alert("Formato del evento no valido");
    }
})

evento_field.addEventListener("keyup", (evento)=>{
    let keyCode = evento.keyCode;
    let evento = evento_field.value;

    if(keyCode == 13){
        submit_btn.click();
    }

    if(evento_regex.test(evento)){
        submit_btn.disabled = false;
    } else {
        submit_btn.disabled = true;
    }
})
